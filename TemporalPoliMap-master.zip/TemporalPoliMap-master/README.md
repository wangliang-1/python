TemporalPoliMap
===============

Fall 2014 CS467 Social Visualization Project 2  
Temporal Political Relation Map using GDELT dataset   

URL: http://shubhanshu.com/TemporalPoliMap/   

Team members:  
Panindra Tumkur Seetharamu, Shubhanshu Mishr, Xiaodan Zhang   

© 2014 All Rights reserved.

